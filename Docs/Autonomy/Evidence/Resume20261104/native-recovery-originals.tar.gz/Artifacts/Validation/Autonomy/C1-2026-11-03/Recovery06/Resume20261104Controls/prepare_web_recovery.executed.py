"""UNEXECUTED preparation only: derive Web controls from actual Native02.

No subprocess, Unity, network, restoration, installation, approval or publication.
Root must first run `native`, then author a real Native review, run `contract
--native-review ...`, and author a separate source approval/envelope.
"""
from pathlib import Path
import argparse
import ast
import copy
import hashlib
import json
import stat
import xml.etree.ElementTree as ET

ROOT = Path('/workspace/firstgame')
ACTUAL = ROOT / 'Artifacts/Validation/Autonomy/C1-resume-2026-11-04/Native02'
C1 = ROOT / 'Artifacts/Validation/Autonomy/C1-2026-11-03'
NATIVE = C1 / 'RecoveryBaseline/NativeRuns/GospelNative02'
CONTROL = C1 / 'Recovery06/Resume20261104Controls'
PACKET = ROOT / 'Tools/Autonomy/Drafts/Recovery06/GospelContainedSource'
FP = '255e2d75bcae088f33f6f2134d44da36296aee85614d726189f79e3c941b8026'
SELECTORS = {key: [key] for key in ('status', 'reviewer', 'sourceFingerprint',
    'nativeXml', 'binding', 'completeOriginalsLedger', 'reviewedUtc')}
SELECTORS.update(productSummary=['summary'], originals=['screenshots'])


def need(value, message):
    if not value:
        raise ValueError(message)


def regular(path):
    path = Path(path)
    return path.is_file() and stat.S_ISREG(path.lstat().st_mode) and not any(
        parent.is_symlink() for parent in (path, *path.parents))


def raw(path):
    need(regular(path), 'Regular original required: ' + str(path))
    return Path(path).read_bytes()


def fullref(path):
    path = Path(path)
    data = raw(path)
    need(path.is_relative_to(ROOT), 'Reference must stay in repository')
    return {'file': str(path.relative_to(ROOT)), 'sha256': hashlib.sha256(data).hexdigest(),
            'bytes': len(data)}


def checked(row):
    need(isinstance(row, dict) and isinstance(row.get('file'), str), 'Exact fullref required')
    path = ROOT / row['file']
    need(path.is_relative_to(ROOT) and fullref(path) == row, 'Original differs: ' + row['file'])
    return path


def load(path):
    return json.loads(raw(path))


def save_bytes(path, data):
    path = Path(path)
    need(path.is_relative_to(C1) and not any(p.is_symlink() for p in (path, *path.parents)),
         'New regular C1 controls only')
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as stream:
        stream.write(data)


def save(path, value):
    save_bytes(path, (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode())


def current_names():
    tree = ast.parse(raw(ROOT / 'Tools/Autonomy/recovery-gospel-native.py'))
    names = next(ast.literal_eval(node.value) for node in tree.body if isinstance(node, ast.Assign)
        and any(isinstance(target, ast.Name) and target.id == 'EXACT_NAMES' for target in node.targets))
    need(len(names) == len(set(names)) == 16, 'Exact original16 cases required')
    return names


def prepare_native():
    need(not NATIVE.exists(), 'Existing controls are preserved; do not rerun or overwrite')
    actual = load(ACTUAL / 'fresh-native-summary.json')
    execution = actual['execution']
    need(actual.get('status') == 'passed' and actual.get('scope') == 'product-native-only'
         and actual.get('publishReady') is False and actual.get('baselineReady') is False
         and execution.get('exitCode') == 0 and execution.get('containmentProvedEmpty') is True,
         'Completed actual Native02 with complete owned cleanup required')
    checked(execution['containmentReceipt'])
    source_native = ACTUAL / 'FreshNative/Native/PathOfDawn'
    binding = load(source_native / 'binding.json')
    names = current_names()
    xml = ET.fromstring(raw(source_native / 'native.xml'))
    cases = xml.findall('.//test-case')
    need(xml.get('result') == 'Passed' and xml.get('passed') == '16'
         and xml.get('failed') == xml.get('skipped') == '0' and len(cases) == 16
         and {case.get('fullname') for case in cases} == set(names)
         and all(case.get('result') == 'Passed' for case in cases), 'Exact16 actual XML pass required')
    need(binding.get('status') == 'passed' and binding.get('exitCode') == 0
         and binding.get('sourceChangedDuringRun') is False and binding.get('sourceFingerprint') == FP
         and binding.get('xmlSha256') == fullref(source_native / 'native.xml')['sha256']
         and binding.get('inputManifestSha256') == fullref(source_native / 'inputs-before.json')['sha256']
         and actual.get('nativeBinding') == binding, 'Current original source/XML/input binding differs')
    fixture = binding['extraFixtureInputs']
    need(len(fixture) == 1 and fixture[0]['file'] == 'Tools/Voice/Nativity/production.json',
         'Exactly one retained real voice fixture required')
    voice = {key: fixture[0][key] for key in ('file', 'sha256', 'bytes')}
    checked(voice)
    saved_voice = dict(voice, file=fixture[0]['preservedFile'])
    checked(saved_voice)
    originals = [fullref(path) for path in sorted((ACTUAL / 'FreshNative/Screenshots').rglob('*'))
                 if path.is_file()]
    pngs = {row['file'][:-4] for row in originals if row['file'].endswith('.png')}
    sidecars = {row['file'][:-8] for row in originals if row['file'].endswith('.png.txt')}
    need(pngs and pngs == sidecars and len(originals) == len(pngs) * 2,
         'Every actual original PNG and its real sidecar required')
    actual_files = []
    for path in sorted(ACTUAL.rglob('*')):
        need(not path.is_symlink(), 'Native evidence must be regular; no link substitution')
        if path.is_file() and 'GeneratedPythonCache' not in path.relative_to(ACTUAL).parts:
            actual_files.append(fullref(path))
    index = {'scope': 'Exact completed current Native02 files; generated Python cache excluded.',
             'fileCount': len(actual_files), 'files': actual_files}
    for filename in ('binding.json', 'native.xml', 'inputs-before.json'):
        save_bytes(NATIVE / 'Native/PathOfDawn' / filename, raw(source_native / filename))
    save(NATIVE / 'whole-current-native-files.json', index)
    summary = {'status': 'passed', 'scope': 'product-native-only', 'publishReady': False,
        'baselineReady': False, 'sourceFingerprint': FP, 'finishedUtc': actual['finishedUtc'],
        'nativeXml': fullref(NATIVE / 'Native/PathOfDawn/native.xml'),
        'binding': fullref(NATIVE / 'Native/PathOfDawn/binding.json'),
        'inputManifest': fullref(NATIVE / 'Native/PathOfDawn/inputs-before.json'),
        'wholeAttemptIndex': fullref(NATIVE / 'whole-current-native-files.json'),
        'voiceFixture': saved_voice, 'originals': originals, 'expectedFullNames': list(names),
        'actualExecutionSummary': fullref(ACTUAL / 'fresh-native-summary.json'),
        'containmentReceipt': execution['containmentReceipt'],
        'source': 'Derived summary binds real completed Native02; no new execution or historical repair.'}
    save(NATIVE / 'product-native-summary.json', summary)
    complete = actual_files + [fullref(path) for path in sorted(NATIVE.rglob('*')) if path.is_file()]
    need(len({row['file'] for row in complete}) == len(complete), 'Duplicate whole evidence paths')
    save(NATIVE / 'complete-current-native-originals.json', {'scope': 'All retained actual Native02 and derived controls before this ledger.',
        'publishReady': False, 'baselineReady': False, 'count': len(complete), 'files': complete})
    inputs = {'scope': 'Root review inputs only; no approval', 'status': 'pending-actual-root-review',
        'sourceFingerprint': FP, 'nativeXml': summary['nativeXml'], 'binding': summary['binding'],
        'summary': fullref(NATIVE / 'product-native-summary.json'),
        'completeOriginalsLedger': fullref(NATIVE / 'complete-current-native-originals.json'),
        'actualOriginals': originals, 'requiredReviewSchemaSelectors': SELECTORS}
    save(NATIVE / 'root-review-inputs.NOT-APPROVED.json', inputs)
    save(NATIVE / 'root-native-review.NOT-APPROVED.template.json', {
        'status': 'TEMPLATE-NOT-APPROVED', 'reviewer': None, 'reviewedUtc': None,
        'scope': 'product-native-only', 'publishReady': False, 'baselineReady': False,
        'sourceFingerprint': FP, 'nativeXml': inputs['nativeXml'], 'binding': inputs['binding'],
        'summary': inputs['summary'], 'completeOriginalsLedger': inputs['completeOriginalsLedger'],
        'screenshots': [], 'limit': 'Template only; Root must directly review and author a separate actual review.'})
    print(json.dumps({'scope': 'native-controls-only', 'nativeReviewInputs': str(NATIVE / 'root-review-inputs.NOT-APPROVED.json'),
                     'nativePngs': len(pngs), 'wholeOriginalCount': len(complete)}))


def prepare_contract(native_review):
    need(not CONTROL.exists(), 'Existing controls are preserved; use a separately reviewed new namespace')
    native_review = Path(native_review)
    need(native_review.is_absolute() and native_review.is_relative_to(C1), 'Actual Root Native review must be inside current C1')
    review = load(native_review)
    inputs = load(NATIVE / 'root-review-inputs.NOT-APPROVED.json')
    need(review.get('status') == 'approved' and review.get('reviewer') in ('root', '/root')
         and review.get('sourceFingerprint') == FP and review.get('publishReady') is False
         and review.get('baselineReady') is False, 'Actual distinct Root review required')
    for key in ('nativeXml', 'binding', 'summary', 'completeOriginalsLedger'):
        need(review.get(key) == inputs[key], 'Root must review these exact Native controls: ' + key)
    approved = review.get('screenshots')
    originals = {row['file']: row for row in inputs['actualOriginals']}
    need(isinstance(approved, list) and len(approved) >= 2 and
         len({row['file'] for row in approved}) == len(approved), 'Distinct actual Root-viewed PNGs required')
    for row in approved:
        need(row['file'].endswith('.png') and originals.get(row['file']) == row, 'Root must bind real current PNG originals')
        checked(row)
    original = load(PACKET / 'source-contract.json')
    contract = copy.deepcopy(original)
    save_bytes(CONTROL / 'command-plan.json', raw(PACKET / 'command-plan.json'))
    contract['commandPlan'] = fullref(CONTROL / 'command-plan.json')
    contract['status'] = 'fresh-native02-linked-held-for-actual-root-source-approval'
    contract['actualFreshNative'].update(binding=inputs['binding'], xml=inputs['nativeXml'],
        inputManifest=fullref(NATIVE / 'Native/PathOfDawn/inputs-before.json'),
        productSummary=inputs['summary'], rootReview=fullref(native_review),
        completeOriginalsLedger=inputs['completeOriginalsLedger'])
    contract['rootReviewSelectors'] = SELECTORS
    save(CONTROL / 'source-contract.json', contract)
    template = load(PACKET / 'root-source-approval.NOT-APPROVED.template.json')
    template.update(status='TEMPLATE-NOT-APPROVED', reviewer=None, reviewedUtc=None,
        sourceContract=fullref(CONTROL / 'source-contract.json'), commandPlan=contract['commandPlan'],
        nativeRootReview=contract['actualFreshNative']['rootReview'], nativeInput=contract['actualFreshNative']['inputManifest'])
    save(CONTROL / 'root-source-approval.NOT-APPROVED.template.json', template)
    envelope = load(PACKET / 'execution-contract.template.json')
    envelope.update(sourceContract=fullref(CONTROL / 'source-contract.json'), rootApproval=None)
    save(CONTROL / 'execution-envelope.NOT-APPROVED.template.json', envelope)
    save(CONTROL / 'change-ledger.json', {'scope': 'Configuration derivation only; no test/build or approval performed.',
        'baseSourceContract': fullref(PACKET / 'source-contract.json'),
        'newSourceContract': fullref(CONTROL / 'source-contract.json'),
        'changedTopLevelKeys': [key for key in original if original[key] != contract[key]],
        'preserved': ['All16 execution/source pins', 'exact16 case names', 'containment helper and acceptance',
            'all readinessfalse', 'shared900/lease60/cleanup12', 'complete current Native originals',
            'fresh Web/current source/public/full-site gates', 'original frozen future Web output namespace']})
    print(json.dumps({'scope': 'contract-draft-only', 'controlRoot': str(CONTROL), 'rootApproval': None}))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('stage', choices=['native', 'contract'])
    parser.add_argument('--native-review', type=Path)
    args = parser.parse_args()
    if args.stage == 'native':
        prepare_native()
    else:
        need(args.native_review is not None, '--native-review actual original is required')
        prepare_contract(args.native_review)


if __name__ == '__main__':
    main()
