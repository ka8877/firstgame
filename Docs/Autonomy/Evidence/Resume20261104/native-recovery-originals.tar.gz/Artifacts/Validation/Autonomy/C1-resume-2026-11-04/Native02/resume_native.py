"""Restore exact saved controls and run the unchanged Gospel Native16 once.

This is current recovery evidence, not a release or historical proof repair.
"""
from pathlib import Path
from datetime import datetime, timezone
import ast
import gzip
import hashlib
import json
import os
import subprocess
import sys
import time
import types
import xml.etree.ElementTree as ET

ROOT = Path('/workspace/firstgame')
RUN = Path(__file__).resolve().parent
LEASE = Path('/tmp/firstgame-resume-2026-11-04/lease.json')


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write('\n')


restored = []
indices = [*ROOT.glob('Docs/Autonomy/Evidence/**/index.json'),
           *ROOT.glob('Tools/Autonomy/Evidence/**/index.json'),
           ROOT / 'Tools/Autonomy/Drafts/Recovery06/GospelContainedSource/recovery-copy-index.json']
for index in indices:
    for row in json.loads(index.read_bytes()).get('files', []):
        if not isinstance(row, dict) or not {'original', 'preserved'} <= row.keys():
            continue
        original, preserved = row['original'], row['preserved']
        destination, source = ROOT / original['file'], ROOT / preserved['file']
        assert destination.is_relative_to(ROOT / 'Artifacts')
        assert source.is_relative_to(ROOT) and source.is_file()
        assert not any(p.is_symlink() for p in (destination, *destination.parents))
        raw = source.read_bytes()
        assert len(raw) == preserved['bytes'] and sha(raw) == preserved['sha256']
        encoding = row.get('encoding', 'identity')
        assert encoding in ('identity', 'gzip-exact-raw-bytes')
        if encoding == 'gzip-exact-raw-bytes':
            raw = gzip.decompress(raw)
        assert len(raw) == original['bytes'] and sha(raw) == original['sha256']
        if destination.exists():
            assert destination.read_bytes() == raw
        else:
            destination.parent.mkdir(parents=True, exist_ok=True)
            with destination.open('xb') as stream:
                stream.write(raw)
        restored.append({'index': str(index.relative_to(ROOT)), **original})
write(RUN / 'restored-exact-controls.json', {'scope': 'Only preserved byte-exact originals; missing historical originals remain missing.',
      'restored': restored, 'count': len(restored), 'observedUtc': datetime.now(timezone.utc).isoformat()})

caller = ROOT / 'Tools/Autonomy/recovery-gospel-native.py'
tree = ast.parse(caller.read_bytes())
names = next(ast.literal_eval(n.value) for n in tree.body if isinstance(n, ast.Assign)
             and any(isinstance(t, ast.Name) and t.id == 'EXACT_NAMES' for t in n.targets))
assert len(names) == len(set(names)) == 16
helper = ROOT / 'Tools/Environment/owned-process-containment.py'
raw_helper = helper.read_bytes()
helper_sha = '9d9082f038566b3dacc74ca8821a5758b85697f246af947f4f7a808bab1e2dad'
assert sha(raw_helper) == helper_sha
module = types.ModuleType('resume_owned_containment')
module.__file__ = str(helper)
sys.modules[module.__name__] = module
exec(compile(raw_helper, str(helper), 'exec', dont_inherit=True), module.__dict__)
contract = json.loads((ROOT / 'Tools/Autonomy/Drafts/Recovery06/GospelContainedSource/source-contract.json').read_bytes())
acceptance = contract['processContainment']['acceptance']
controller = module.Controller({'helperPath': str(helper), 'helperSha256': helper_sha,
    'evidenceRoot': str(RUN / 'ContainmentControls'), 'acceptance': acceptance}, ROOT)


class Lane:
    def __init__(self):
        self.started = time.monotonic()
        self.safe_end = self.started + 900
        self.deadline = datetime.fromisoformat(json.loads(LEASE.read_bytes())['lease']['deadlineUtc'])
        self.run, self.events, self.logs = RUN, [], []
        self.env = dict(os.environ,
            FIRSTGAME_VALIDATION_ROOT=str(RUN / 'FreshNative'),
            FIRSTGAME_BUILD_ROOT='/tmp/firstgame-gospel-recovery-builds-20261104',
            FIRSTGAME_NATIVE_FILTER=';'.join(names),
            FIRSTGAME_NATIVE_CAPTURE_ROOT=str(RUN / 'FreshNative/Screenshots'),
            FIRSTGAME_NATIVE_ATTEMPT='GospelNative02',
            PYTHONPYCACHEPREFIX=str(RUN / 'GeneratedPythonCache'), PYTHONDONTWRITEBYTECODE='1')

    def remaining(self):
        now = time.monotonic()
        self.safe_end = min(self.safe_end, now + (self.deadline - datetime.now(timezone.utc)).total_seconds() - 60)
        assert self.safe_end > now
        return self.safe_end - now


lane = Lane()
guard = [sys.executable, str(ROOT / 'Tools/Autonomy/cycle_guard.py'), 'check', '--record', str(LEASE)]
assert controller.child(lane, 'ownership', guard, cap=45)['exitCode'] == 0
library = ROOT / 'Games/PathOfDawn/Library'
target = Path('/tmp/firstgame-reprise-cache/PathOfDawn/Library')
target.mkdir(parents=True, exist_ok=True)
if not library.exists() and not library.is_symlink():
    library.symlink_to(target, target_is_directory=True)
assert library.is_symlink() and library.readlink() == target
write(RUN / 'native-invocation.json', {'scope': 'Fresh unchanged Native16; no publication approval.',
      'exactNames': list(names), 'helperSha256': helper_sha, 'acceptance': acceptance,
      'lease': json.loads(LEASE.read_bytes()), 'maximumSeconds': 900,
      'libraryAlias': {'file': str(library), 'target': str(target)}})
result = controller.child(lane, 'fresh-native16',
    [sys.executable, str(ROOT / 'Tools/Validation/run-nativity-native.py'), 'PathOfDawn', 'GospelNative02'], cap=900)
summary = {'status': 'failed', 'scope': 'product-native-only', 'publishReady': False,
    'baselineReady': False, 'execution': result, 'expectedNames': list(names),
    'finishedUtc': datetime.now(timezone.utc).isoformat()}
native = RUN / 'FreshNative/Native/PathOfDawn'
if result['exitCode'] == 0 and (native / 'native.xml').is_file():
    xml = ET.parse(native / 'native.xml').getroot()
    cases = xml.findall('.//test-case')
    binding = json.loads((native / 'binding.json').read_bytes())
    assert len(cases) == 16 and {c.get('fullname') for c in cases} == set(names)
    assert all(c.get('result') == 'Passed' for c in cases)
    assert xml.get('failed') == xml.get('skipped') == '0'
    assert binding['status'] == 'passed' and binding['sourceChangedDuringRun'] is False
    summary.update(status='passed', nativeBinding=binding)
write(RUN / 'fresh-native-summary.json', summary)
print(json.dumps({'status': summary['status'], 'exitCode': result['exitCode'], 'summary': str(RUN / 'fresh-native-summary.json')}))
raise SystemExit(0 if summary['status'] == 'passed' else 1)
